create definer = root@localhost trigger del_ins_account
    after delete
    on instructor
    for each row
    delete from account where ID = old.workID;

