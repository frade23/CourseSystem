create trigger del_stu_account
  after DELETE
  on student
  for each row
  delete from account where ID = old.stuID;

