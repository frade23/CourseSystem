create definer = root@localhost trigger del_stu_account
    after delete
    on student
    for each row
    delete from account where ID = old.stuID;

